# ShakeTorch

A minimal, offline Android flashlight utility.

## Features
- Shake to toggle the phone flashlight
- Foreground service for screen-off operation
- Adjustable shake threshold
- Optional proximity-based pocket mode
- No account, ads, subscription, backend, or internet permission

## Open in Android Studio
1. Extract this ZIP.
2. Open the `ShakeTorch` folder in Android Studio.
3. Install Android SDK Platform 35 if prompted.
4. Use JDK 17 (Android Studio's embedded JDK is suitable).
5. Sync Gradle, connect your Android phone, and press Run.
6. Grant Camera and notification permissions.
7. Tap **START SHAKE CONTROL**.

## Important Android behavior
- Screen-off shake detection depends on the phone's sensor and firmware. Some manufacturers aggressively restrict background services; allow ShakeTorch background/autostart activity in system settings if needed.
- Android 14+ requires a special-use foreground-service declaration for this persistent sensor task. Google Play review may require justification for this service type.
- Pocket mode uses the proximity sensor. It may be unavailable or behave differently on some devices.
- The app intentionally has no internet permission.

## Build APK
In Android Studio: Build > Build Bundle(s) / APK(s) > Build APK(s).
The debug APK is normally at `app/build/outputs/apk/debug/app-debug.apk`.
