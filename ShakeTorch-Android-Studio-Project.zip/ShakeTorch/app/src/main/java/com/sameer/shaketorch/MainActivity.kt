package com.sameer.shaketorch

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FlashlightOn
import androidx.compose.material.icons.filled.FlashlightOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat

private const val PREFS = "shake_torch_settings"

class MainActivity : ComponentActivity() {
    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val needed = buildList {
            if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) add(Manifest.permission.CAMERA)
            if (Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (needed.isNotEmpty()) permissionLauncher.launch(needed.toTypedArray())

        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        setContent {
            val purple = Color(0xFF7357F6)
            var enabled by remember { mutableStateOf(prefs.getBoolean("enabled", false)) }
            var pocket by remember { mutableStateOf(prefs.getBoolean("pocket", true)) }
            var sensitivity by remember { mutableFloatStateOf(prefs.getFloat("sensitivity", 2.7f)) }

            MaterialTheme(
                colorScheme = lightColorScheme(primary = purple, background = Color(0xFFF7F6FB))
            ) {
                Surface(Modifier.fillMaxSize(), color = Color(0xFFF7F6FB)) {
                    Column(
                        Modifier.fillMaxSize().padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Spacer(Modifier.height(22.dp))
                        Text("ShakeTorch", style = MaterialTheme.typography.headlineLarge)
                        Text("Your flashlight. One shake away.", color = Color.Gray)
                        Spacer(Modifier.height(34.dp))

                        Box(
                            Modifier.size(190.dp).background(Color(0xFFECE8FF), RoundedCornerShape(48.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                if (enabled) Icons.Default.FlashlightOn else Icons.Default.FlashlightOff,
                                contentDescription = null,
                                tint = purple,
                                modifier = Modifier.size(100.dp)
                            )
                        }
                        Spacer(Modifier.height(24.dp))
                        Text(if (enabled) "Shake detection is ON" else "Shake detection is OFF",
                            style = MaterialTheme.typography.titleLarge)
                        Spacer(Modifier.height(14.dp))
                        Button(
                            onClick = {
                                if (!enabled) {
                                    if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.CAMERA)
                                        == PackageManager.PERMISSION_GRANTED) {
                                        enabled = true
                                        prefs.edit().putBoolean("enabled", true).apply()
                                        ContextCompat.startForegroundService(
                                            this@MainActivity,
                                            Intent(this@MainActivity, TorchService::class.java)
                                                .setAction(TorchService.ACTION_START)
                                        )
                                    } else {
                                        permissionLauncher.launch(arrayOf(Manifest.permission.CAMERA))
                                    }
                                } else {
                                    enabled = false
                                    prefs.edit().putBoolean("enabled", false).apply()
                                    stopService(Intent(this@MainActivity, TorchService::class.java))
                                }
                            },
                            modifier = Modifier.fillMaxWidth().height(56.dp),
                            shape = RoundedCornerShape(18.dp)
                        ) {
                            Text(if (enabled) "STOP SHAKE CONTROL" else "START SHAKE CONTROL")
                        }

                        Spacer(Modifier.height(28.dp))
                        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp)) {
                            Column(Modifier.padding(20.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("Shake sensitivity", modifier = Modifier.weight(1f),
                                        style = MaterialTheme.typography.titleMedium)
                                    Text(String.format("%.1f", sensitivity), color = purple)
                                }
                                Slider(
                                    value = sensitivity,
                                    onValueChange = {
                                        sensitivity = it
                                        prefs.edit().putFloat("sensitivity", it).apply()
                                        sendUpdate()
                                    },
                                    valueRange = 1.5f..5.5f
                                )
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("More sensitive", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                                    Text("Less sensitive", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                                }
                                HorizontalDivider(Modifier.padding(vertical = 12.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text("Pocket mode", style = MaterialTheme.typography.titleMedium)
                                        Text("Ignore shakes when the proximity sensor is covered.",
                                            style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                                    }
                                    Switch(
                                        checked = pocket,
                                        onCheckedChange = {
                                            pocket = it
                                            prefs.edit().putBoolean("pocket", it).apply()
                                            sendUpdate()
                                        }
                                    )
                                }
                            }
                        }
                        Spacer(Modifier.height(18.dp))
                        Text("Runs in the background using an ongoing notification.",
                            style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                        Text("No account • No ads • No server", color = purple,
                            style = MaterialTheme.typography.labelMedium)
                    }
                }
            }
        }
    }

    private fun sendUpdate() {
        if (getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean("enabled", false)) {
            startService(Intent(this, TorchService::class.java).setAction(TorchService.ACTION_UPDATE))
        }
    }
}
