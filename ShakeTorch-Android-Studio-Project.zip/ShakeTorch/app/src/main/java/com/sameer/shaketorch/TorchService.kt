package com.sameer.shaketorch

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.camera2.CameraManager
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import kotlin.math.sqrt

class TorchService : Service(), SensorEventListener {
    companion object {
        const val ACTION_START = "com.sameer.shaketorch.START"
        const val ACTION_UPDATE = "com.sameer.shaketorch.UPDATE"
        private const val CHANNEL_ID = "shake_torch_running"
        private const val NOTIFICATION_ID = 41
        private const val PREFS = "shake_torch_settings"
    }

    private lateinit var sensorManager: SensorManager
    private lateinit var cameraManager: CameraManager
    private var accelerometer: Sensor? = null
    private var proximity: Sensor? = null
    private var cameraId: String? = null
    private var torchOn = false
    private var pocketCovered = false
    private var lastShake = 0L
    private var lastAcceleration = 0f
    private var sensitivity = 2.7f
    private var pocketMode = true

    override fun onCreate() {
        super.onCreate()
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        cameraManager = getSystemService(Context.CAMERA_SERVICE) as CameraManager
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        proximity = sensorManager.getDefaultSensor(Sensor.TYPE_PROXIMITY)
        cameraId = cameraManager.cameraIdList.firstOrNull { id ->
            cameraManager.getCameraCharacteristics(id)
                .get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        }
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_START || intent?.action == ACTION_UPDATE || intent == null) {
            startForeground(NOTIFICATION_ID, buildNotification())
            loadSettings()
            registerSensors()
        }
        return START_STICKY
    }

    private fun loadSettings() {
        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        sensitivity = prefs.getFloat("sensitivity", 2.7f)
        pocketMode = prefs.getBoolean("pocket", true)
    }

    private fun registerSensors() {
        accelerometer?.let { sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
        if (pocketMode) {
            proximity?.let { sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_NORMAL) }
        } else {
            proximity?.let { sensorManager.unregisterListener(this, it) }
            pocketCovered = false
        }
    }

    override fun onSensorChanged(event: SensorEvent) {
        when (event.sensor.type) {
            Sensor.TYPE_PROXIMITY -> {
                val maxRange = event.sensor.maximumRange
                pocketCovered = event.values[0] < maxRange
            }
            Sensor.TYPE_ACCELEROMETER -> {
                val x = event.values[0]
                val y = event.values[1]
                val z = event.values[2]
                val magnitude = sqrt(x * x + y * y + z * z)
                val delta = kotlin.math.abs(magnitude - SensorManager.GRAVITY_EARTH)
                val now = SystemClock.elapsedRealtime()
                val threshold = sensitivity * 2.0f
                if (delta > threshold && delta > lastAcceleration &&
                    now - lastShake > 900L && !(pocketMode && pocketCovered)) {
                    lastShake = now
                    toggleTorch()
                }
                lastAcceleration = delta
            }
        }
    }

    private fun toggleTorch() {
        val id = cameraId ?: return
        try {
            torchOn = !torchOn
            cameraManager.setTorchMode(id, torchOn)
        } catch (_: Exception) {
            torchOn = false
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    override fun onDestroy() {
        sensorManager.unregisterListener(this)
        if (torchOn) {
            try { cameraId?.let { cameraManager.setTorchMode(it, false) } } catch (_: Exception) { }
        }
        super.onDestroy()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "ShakeTorch is active", NotificationManager.IMPORTANCE_LOW
            ).apply { description = "Keeps shake detection active while the screen is off." }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("ShakeTorch is running")
            .setContentText("Shake your phone to toggle the flashlight")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()

    override fun onBind(intent: Intent?): IBinder? = null
}
